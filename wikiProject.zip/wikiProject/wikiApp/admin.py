from django.contrib import admin
from.models import SearchBarModel, NewEntryModel ,RelatedEntryModel
admin.site.register(SearchBarModel)
admin.site.register(NewEntryModel)
admin.site.register(RelatedEntryModel)

# Register your models here.
