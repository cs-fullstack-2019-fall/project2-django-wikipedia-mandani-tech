from django.apps import AppConfig


class WikiappConfig(AppConfig):
    name = 'wikiApp'
